(function () {
  const React = revenge.react.React;
  const RN = revenge.react.ReactNative;
  const Flux = revenge.discord.flux;
  const Stores = Flux.Stores;
  const onFluxEventDispatched = Flux.onFluxEventDispatched;
  const h = React.createElement;
  const DEFAULTS = {
    userIds: '',
    notifyOffline: false,
    notifyStatusChanges: false
  };
  let liveSettings = Object.assign({}, DEFAULTS);
  const previousStatuses = new Map();

  function parseIds(value) {
    return new Set(String(value || '').match(/\d{15,22}/g) || []);
  }

  function normalizedStatus(value) {
    const status = String(value == null ? 'offline' : value).toLowerCase();
    if (status === 'online' || status === 'idle' || status === 'dnd') return status;
    return 'offline';
  }

  function statusLabel(status) {
    if (status === 'online') return 'в сети';
    if (status === 'idle') return 'неактивен';
    if (status === 'dnd') return 'не беспокоить';
    return 'не в сети';
  }

  function getPayloadUserId(payload) {
    const value = payload && (
      (payload.user && payload.user.id) ||
      payload.userId ||
      payload.user_id ||
      (payload.presence && payload.presence.user && payload.presence.user.id) ||
      payload.id
    );
    return value == null ? '' : String(value);
  }

  function getStoreStatus(userId) {
    try {
      const store = Stores && Stores.PresenceStore;
      if (!store) return 'offline';
      const direct = typeof store.getStatus === 'function' ? store.getStatus(userId) : null;
      if (direct != null) return normalizedStatus(direct);
      const presence = typeof store.getPresence === 'function' ? store.getPresence(userId) : null;
      if (presence && presence.status != null) return normalizedStatus(presence.status);
      const state = typeof store.getState === 'function' ? store.getState() : null;
      if (state && state[userId] && state[userId].status != null) return normalizedStatus(state[userId].status);
    } catch (_) {}
    return 'offline';
  }

  function getPayloadStatus(payload, userId) {
    const explicit = payload && (
      payload.status ||
      (payload.presence && payload.presence.status) ||
      (payload.user && payload.user.status)
    );
    if (explicit != null) return normalizedStatus(explicit);
    const clientStatus = payload && (payload.clientStatus || payload.client_status);
    if (clientStatus && typeof clientStatus === 'object') {
      const values = Object.values(clientStatus).map(normalizedStatus);
      if (values.indexOf('online') !== -1) return 'online';
      if (values.indexOf('dnd') !== -1) return 'dnd';
      if (values.indexOf('idle') !== -1) return 'idle';
    }
    return getStoreStatus(userId);
  }

  function displayName(payload, userId) {
    let name = payload && (
      (payload.user && (payload.user.globalName || payload.user.global_name || payload.user.username)) ||
      (payload.presence && payload.presence.user && (payload.presence.user.globalName || payload.presence.user.global_name || payload.presence.user.username))
    );
    if (!name) {
      try {
        const user = Stores && Stores.UserStore && typeof Stores.UserStore.getUser === 'function'
          ? Stores.UserStore.getUser(userId)
          : null;
        name = user && (user.globalName || user.global_name || user.username);
      } catch (_) {}
    }
    return name || userId;
  }

  function notify(message) {
    let sent = false;
    try {
      const nativeModules = RN && RN.NativeModules;
      const push = nativeModules && nativeModules.PushNotificationAndroid;
      if (push && typeof push.presentLocalNotification === 'function') {
        push.presentLocalNotification({ alertBody: message });
        sent = true;
      }
    } catch (_) {}
    if (!sent) {
      try {
        if (RN.ToastAndroid && typeof RN.ToastAndroid.show === 'function') {
          RN.ToastAndroid.show(message, RN.ToastAndroid.LONG);
        }
      } catch (_) {}
    }
  }

  function primeStatuses(ids) {
    ids.forEach(function (id) {
      if (!previousStatuses.has(id)) previousStatuses.set(id, getStoreStatus(id));
    });
    Array.from(previousStatuses.keys()).forEach(function (id) {
      if (!ids.has(id)) previousStatuses.delete(id);
    });
  }

  const styles = RN.StyleSheet.create({
    page: { padding: 16, gap: 12 },
    card: { borderRadius: 16, padding: 16, backgroundColor: '#202225', gap: 10 },
    title: { color: '#ffffff', fontSize: 22, fontWeight: '700' },
    subtitle: { color: '#b5bac1', fontSize: 14, lineHeight: 20 },
    label: { color: '#f2f3f5', fontSize: 15, fontWeight: '600' },
    hint: { color: '#949ba4', fontSize: 12, lineHeight: 17 },
    input: { borderRadius: 10, backgroundColor: '#111214', color: '#ffffff', paddingHorizontal: 12, paddingVertical: 11, fontSize: 15 },
    button: { alignSelf: 'flex-start', borderRadius: 10, backgroundColor: '#5865f2', paddingHorizontal: 14, paddingVertical: 10 },
    testButton: { borderRadius: 12, backgroundColor: '#5865f2', paddingHorizontal: 16, paddingVertical: 13, alignItems: 'center' },
    buttonText: { color: '#ffffff', fontWeight: '700' },
    row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    rowText: { flex: 1, gap: 4 },
    separator: { height: RN.StyleSheet.hairlineWidth, backgroundColor: '#3f4147' },
    footer: { color: '#7d828a', fontSize: 12, lineHeight: 17, paddingHorizontal: 4, paddingBottom: 16 }
  });

  function SettingsComponent(props) {
    const api = props.api;
    const stored = api.jsonStorage.use() || DEFAULTS;
    const state = React.useState(stored.userIds || '');
    const userIds = state[0];
    const setUserIds = state[1];

    React.useEffect(function () {
      setUserIds(stored.userIds || '');
    }, [stored.userIds]);

    const count = React.useMemo(function () {
      return parseIds(userIds).size;
    }, [userIds]);

    function saveIds() {
      const clean = Array.from(parseIds(userIds)).join(', ');
      setUserIds(clean);
      void api.jsonStorage.set({ userIds: clean });
    }

    return h(RN.ScrollView, { contentContainerStyle: styles.page },
      h(RN.View, { style: styles.card },
        h(RN.Text, { style: styles.title }, 'PresenceWatch'),
        h(RN.Text, { style: styles.subtitle }, 'Уведомляет, когда выбранный пользователь Discord появляется в сети.')
      ),
      h(RN.View, { style: styles.card },
        h(RN.Text, { style: styles.label }, 'Discord ID'),
        h(RN.TextInput, {
          value: userIds,
          onChangeText: setUserIds,
          onBlur: saveIds,
          onSubmitEditing: saveIds,
          placeholder: '123456789012345678',
          placeholderTextColor: '#777',
          keyboardType: 'numeric',
          style: styles.input
        }),
        h(RN.Text, { style: styles.hint }, 'Можно указать несколько ID через запятую или с новой строки. Сейчас: ' + count + '.'),
        h(RN.Pressable, { style: styles.button, onPress: saveIds },
          h(RN.Text, { style: styles.buttonText }, 'Сохранить ID')
        )
      ),
      h(RN.View, { style: styles.card },
        h(RN.View, { style: styles.row },
          h(RN.View, { style: styles.rowText },
            h(RN.Text, { style: styles.label }, 'Уведомлять о выходе'),
            h(RN.Text, { style: styles.hint }, 'Показывать уведомление при переходе в offline.')
          ),
          h(RN.Switch, {
            value: !!stored.notifyOffline,
            onValueChange: function (value) { void api.jsonStorage.set({ notifyOffline: value }); }
          })
        ),
        h(RN.View, { style: styles.separator }),
        h(RN.View, { style: styles.row },
          h(RN.View, { style: styles.rowText },
            h(RN.Text, { style: styles.label }, 'Смена Online / Idle / DND'),
            h(RN.Text, { style: styles.hint }, 'Уведомлять и о смене активного статуса.')
          ),
          h(RN.Switch, {
            value: !!stored.notifyStatusChanges,
            onValueChange: function (value) { void api.jsonStorage.set({ notifyStatusChanges: value }); }
          })
        )
      ),
      h(RN.Pressable, {
        style: styles.testButton,
        onPress: function () { notify('🟢 PresenceWatch: тестовое уведомление работает'); }
      }, h(RN.Text, { style: styles.buttonText }, 'Проверить уведомление')),
      h(RN.Text, { style: styles.footer }, 'Invisible определить нельзя: Discord передаёт такой статус как offline. Плагин реагирует только на presence-события, которые получает твой клиент Discord.')
    );
  }

  return {
    default: plugin({
      jsonStorage: {
        load: true,
        default: DEFAULTS
      },
      SettingsComponent: SettingsComponent,
      async start(api) {
        const stored = await api.jsonStorage.get();
        liveSettings = Object.assign({}, DEFAULTS, stored || {});
        primeStatuses(parseIds(liveSettings.userIds));

        const unsubscribeStorage = api.jsonStorage.subscribe(function (update) {
          liveSettings = Object.assign({}, liveSettings, update || {});
          primeStatuses(parseIds(liveSettings.userIds));
        });

        const unsubscribePresence = onFluxEventDispatched('PRESENCE_UPDATE', function (payload) {
          const userId = getPayloadUserId(payload);
          if (!userId) return payload;
          const watched = parseIds(liveSettings.userIds);
          if (!watched.has(userId)) return payload;

          const next = getPayloadStatus(payload, userId);
          const prev = previousStatuses.has(userId) ? previousStatuses.get(userId) : getStoreStatus(userId);
          previousStatuses.set(userId, next);
          const name = displayName(payload, userId);

          if (prev === 'offline' && next !== 'offline') {
            notify('🟢 ' + name + ' ' + statusLabel(next));
          } else if (prev !== 'offline' && next === 'offline' && liveSettings.notifyOffline) {
            notify('⚫ ' + name + ' вышел из сети');
          } else if (prev !== next && prev !== 'offline' && next !== 'offline' && liveSettings.notifyStatusChanges) {
            notify('🟡 ' + name + ': ' + statusLabel(next));
          }
          return payload;
        });

        if (typeof api.cleanup === 'function') {
          api.cleanup(unsubscribeStorage, unsubscribePresence);
        }
      },
      stop() {
        previousStatuses.clear();
      }
    })
  };
})()
